"use client";
import { useState } from "react";

const fmt = (v, sfx = "%") => {
  if (v == null || v === "N/A") return "\u2014";
  const n = typeof v === "string" ? parseFloat(v) : v;
  if (isNaN(n)) return "\u2014";
  const s = n > 0 ? "+" : "";
  return `${s}${n.toFixed(sfx === " bps" ? 1 : 2)}${sfx}`;
};
const clr = (v) => {
  const n = typeof v === "string" ? parseFloat(v) : v;
  if (isNaN(n) || n === 0) return "#94a3b8";
  return n > 0 ? "#34d399" : "#f87171";
};
const NumCell = ({ val, sfx = "%" }) => (
  <td style={{ textAlign: "right", padding: "7px 10px", fontFamily: "'Courier New',monospace", fontSize: 13, color: clr(val), fontWeight: 600 }}>{fmt(val, sfx)}</td>
);
const Th = ({ children, left }) => (
  <th style={{ textAlign: left ? "left" : "right", padding: "6px 10px", color: "#64748b", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em", borderBottom: "1px solid rgba(100,116,139,.15)", whiteSpace: "nowrap" }}>{children}</th>
);
const Td = ({ children, left, bold, color }) => (
  <td style={{ textAlign: left ? "left" : "right", padding: "7px 10px", color: color || "#e2e8f0", fontSize: 13, fontWeight: bold ? 700 : 500, whiteSpace: "nowrap" }}>{children}</td>
);
const Tbl = ({ children }) => (
  <div style={{ overflowX: "auto" }}><table style={{ width: "100%", borderCollapse: "separate", borderSpacing: "0 1px" }}>{children}</table></div>
);
const Section = ({ title, icon, accent, children, sub }) => (
  <div style={{ background: "rgba(15,23,42,.7)", backdropFilter: "blur(12px)", border: "1px solid rgba(100,116,139,.12)", borderRadius: 12, padding: "16px 18px", marginBottom: 16, borderLeft: `3px solid ${accent}` }}>
    <div style={{ fontSize: 12, fontWeight: 700, color: "#cbd5e1", textTransform: "uppercase", letterSpacing: ".07em", marginBottom: sub ? 2 : 10, display: "flex", alignItems: "center", gap: 7 }}>
      <span style={{ fontSize: 15 }}>{icon}</span>{title}
    </div>
    {sub && <div style={{ fontSize: 10, color: "#475569", marginBottom: 10, fontStyle: "italic", marginLeft: 22 }}>{sub}</div>}
    {children}
  </div>
);
const YieldBox = ({ label, val, sfx }) => (
  <div style={{ textAlign: "center", minWidth: 90 }}>
    <div style={{ color: clr(val), fontSize: 18, fontWeight: 700, fontFamily: "'Courier New',monospace" }}>{fmt(val, sfx)}</div>
    <div style={{ color: "#64748b", fontSize: 10, marginTop: 2 }}>{label}</div>
  </div>
);
const Bar = ({ val, max = 25 }) => {
  const n = typeof val === "number" ? val : parseFloat(val) || 0;
  const w = Math.min(Math.abs(n) / max * 100, 100);
  const pos = n >= 0;
  return (
    <div style={{ display: "flex", alignItems: "center", height: 14 }}>
      <div style={{ flex: 1, display: "flex", justifyContent: "flex-end" }}>{!pos && <div style={{ height: 5, width: `${w}%`, background: "linear-gradient(270deg,#f87171,#991b1b)", borderRadius: 3, minWidth: 2 }} />}</div>
      <div style={{ width: 1, height: 12, background: "#334155", flexShrink: 0 }} />
      <div style={{ flex: 1 }}>{pos && <div style={{ height: 5, width: `${w}%`, background: "linear-gradient(90deg,#34d399,#059669)", borderRadius: 3, minWidth: 2 }} />}</div>
    </div>
  );
};
const Note = ({ color, bg, children }) => (
  <div style={{ marginTop: 10, padding: "8px 10px", background: bg, borderRadius: 6, fontSize: 11, color, lineHeight: 1.5 }}>{children}</div>
);

export default function Dashboard({ data }) {
  const [tab, setTab] = useState("overview");
  const tabs = [["overview", "Overview"], ["commodities", "Commodities"], ["movers", "Top & Bottom Stocks"], ["global", "Global Markets"]];

  if (!data) {
    return (
      <div style={{ minHeight: "100vh", background: "#020617", color: "#e2e8f0", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "system-ui" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 40, marginBottom: 16 }}>&#x26A0;&#xFE0F;</div>
          <h2 style={{ margin: "0 0 8px", fontSize: 18 }}>Unable to load market data</h2>
          <p style={{ color: "#64748b", fontSize: 13 }}>Please check your FMP_API_KEY environment variable and try again.</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg,#020617,#0f172a 50%,#0c1220)", color: "#e2e8f0", fontFamily: "'Segoe UI',system-ui,-apple-system,sans-serif", padding: 20 }}>
      <style>{`@keyframes si{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}.an{animation:si .3s ease forwards}::-webkit-scrollbar{width:5px;height:5px}::-webkit-scrollbar-thumb{background:rgba(100,116,139,.25);border-radius:3px}`}</style>

      {/* HEADER */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10, marginBottom: 18 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg,#3b82f6,#06b6d4)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M3 3v18h18"/><path d="M7 16l4-8 4 4 6-10"/></svg>
            </div>
            <h1 style={{ margin: 0, fontSize: 20, fontWeight: 800, letterSpacing: "-.02em", color: "#f1f5f9" }}>Global Markets Dashboard</h1>
          </div>
          <p style={{ margin: "3px 0 0 42px", fontSize: 11, color: "#64748b" }}>Daily briefing: indices, commodities, sectors, movers & global markets</p>
        </div>
        <div style={{ fontSize: 11, color: "#475569", textAlign: "right" }}>
          <div style={{ color: "#94a3b8", fontWeight: 600 }}>{data.asOf}</div>
          <div>{data.source}</div>
        </div>
      </div>

      {/* TABS */}
      <div style={{ display: "flex", gap: 4, marginBottom: 16, flexWrap: "wrap" }}>
        {tabs.map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} style={{ padding: "6px 16px", borderRadius: 6, border: "none", cursor: "pointer", fontSize: 12, fontWeight: 600, background: tab === k ? "rgba(59,130,246,.2)" : "rgba(30,41,59,.5)", color: tab === k ? "#60a5fa" : "#64748b", borderBottom: tab === k ? "2px solid #3b82f6" : "2px solid transparent" }}>{l}</button>
        ))}
      </div>

      {/* OVERVIEW */}
      {tab === "overview" && (
        <div className="an">
          <Section title="US 10-Year Treasury Yield" icon="&#x1F3DB;" accent="#f59e0b">
            <div style={{ display: "flex", alignItems: "center", gap: 30, flexWrap: "wrap" }}>
              <div>
                <div style={{ fontSize: 32, fontWeight: 800, fontFamily: "'Courier New',monospace", color: "#f8fafc" }}>{data.treasury.yield}%</div>
                <div style={{ fontSize: 10, color: "#64748b" }}>Current Yield</div>
              </div>
              <YieldBox label="1-Day Change" val={data.treasury.change1d} sfx=" bps" />
              {data.treasury.change1w && <YieldBox label="1-Week Change" val={data.treasury.change1w} sfx=" bps" />}
            </div>
          </Section>
          <Section title="Global & US Equity Indices" icon="&#x1F4C8;" accent="#3b82f6">
            <Tbl><thead><tr><Th left>Index</Th><Th>Level</Th><Th>1D</Th><Th>1W</Th><Th>1M</Th><Th>YTD</Th></tr></thead>
              <tbody>{(data.indices || []).map((r, i) => (
                <tr key={i} style={{ background: i % 2 === 0 ? "rgba(30,41,59,.35)" : "transparent" }}>
                  <Td left bold>{r.name}</Td><Td>{r.level}</Td>
                  <NumCell val={r.d1} /><NumCell val={r.w1} /><NumCell val={r.m1} /><NumCell val={r.ytd} />
                </tr>
              ))}</tbody>
            </Tbl>
          </Section>
          <Section title="S&P 500 GICS Sector Performance" icon="&#x1F3D7;" accent="#8b5cf6" sub="Sorted by YTD — highest to lowest">
            <Tbl><thead><tr><Th left>Sector</Th><Th>1D</Th><Th>1W</Th><Th>YTD</Th><th style={{ width: 110, padding: "6px 10px" }}></th></tr></thead>
              <tbody>{(data.sectors || []).map((r, i) => (
                <tr key={i} style={{ background: i % 2 === 0 ? "rgba(30,41,59,.35)" : "transparent" }}>
                  <Td left bold>{r.name}</Td>
                  <NumCell val={r.d1} /><NumCell val={r.w1} /><NumCell val={r.ytd} />
                  <td style={{ padding: "4px 10px" }}><Bar val={r.ytd} /></td>
                </tr>
              ))}</tbody>
            </Tbl>
          </Section>
        </div>
      )}

      {/* COMMODITIES */}
      {tab === "commodities" && (
        <div className="an">
          <Section title="Commodity & Crypto Prices" icon="&#x1F4B0;" accent="#f59e0b" sub="Precious metals, energy, industrial metals & digital assets">
            <Tbl><thead><tr><Th left>Asset</Th><Th>Price</Th><Th>1D</Th><Th>1W</Th><Th>1M</Th><Th>YTD</Th></tr></thead>
              <tbody>{(data.commodities || []).map((r, i) => (
                <tr key={i} style={{ background: i % 2 === 0 ? "rgba(30,41,59,.35)" : "transparent" }}>
                  <Td left bold>{r.icon} {r.name}</Td>
                  <Td><span style={{ fontFamily: "'Courier New',monospace", fontWeight: 700, color: "#f1f5f9" }}>{r.price}</span><span style={{ color: "#475569", fontSize: 10 }}>{r.unit}</span></Td>
                  <NumCell val={r.d1} /><NumCell val={r.w1} /><NumCell val={r.m1} /><NumCell val={r.ytd} />
                </tr>
              ))}</tbody>
            </Tbl>
          </Section>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 10 }}>
            {(data.commodities || []).map((c, i) => (
              <div key={i} style={{ background: "rgba(15,23,42,.7)", border: "1px solid rgba(100,116,139,.12)", borderRadius: 10, padding: "14px 16px", textAlign: "center" }}>
                <div style={{ fontSize: 22, marginBottom: 4 }}>{c.icon}</div>
                <div style={{ fontSize: 11, color: "#94a3b8", fontWeight: 600, marginBottom: 4 }}>{c.name}</div>
                <div style={{ fontSize: 18, fontWeight: 800, fontFamily: "'Courier New',monospace", color: "#f1f5f9" }}>{c.price}</div>
                <div style={{ fontSize: 13, fontWeight: 700, fontFamily: "'Courier New',monospace", color: clr(c.ytd), marginTop: 4 }}>{fmt(c.ytd)} YTD</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MOVERS */}
      {tab === "movers" && (
        <div className="an" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))", gap: 16 }}>
          <Section title="Top 10 Best Performing Stocks (>$10B)" icon="&#x1F680;" accent="#34d399">
            <Tbl><thead><tr><Th left>#</Th><Th left>Ticker</Th><Th left>Company</Th><Th>1W</Th><Th>1M</Th><Th>YTD</Th></tr></thead>
              <tbody>{(data.topStocks || []).map((r, i) => (
                <tr key={i} style={{ background: i % 2 === 0 ? "rgba(30,41,59,.35)" : "transparent" }}>
                  <Td left>{i + 1}</Td><Td left bold color="#60a5fa">{r.ticker}</Td><Td left>{r.name}</Td>
                  <NumCell val={r.w1} /><NumCell val={r.m1} /><NumCell val={r.ytd} />
                </tr>
              ))}</tbody>
            </Tbl>
          </Section>
          <Section title="Bottom 10 Worst Performing Stocks (>$10B)" icon="&#x1F4C9;" accent="#f87171">
            <Tbl><thead><tr><Th left>#</Th><Th left>Ticker</Th><Th left>Company</Th><Th>1W</Th><Th>1M</Th><Th>YTD</Th></tr></thead>
              <tbody>{(data.bottomStocks || []).map((r, i) => (
                <tr key={i} style={{ background: i % 2 === 0 ? "rgba(30,41,59,.35)" : "transparent" }}>
                  <Td left>{i + 1}</Td><Td left bold color="#fb923c">{r.ticker}</Td><Td left>{r.name}</Td>
                  <NumCell val={r.w1} /><NumCell val={r.m1} /><NumCell val={r.ytd} />
                </tr>
              ))}</tbody>
            </Tbl>
          </Section>
        </div>
      )}

      {/* GLOBAL MARKETS */}
      {tab === "global" && (
        <div className="an">
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))", gap: 16 }}>
            <Section title="Top 5 Global Markets \u2014 YTD" icon="&#x1F30D;" accent="#34d399">
              <Tbl><thead><tr><Th left>#</Th><Th left>Market</Th><Th left>Index</Th><Th>YTD</Th></tr></thead>
                <tbody>{(data.topMarkets || []).map((r, i) => (
                  <tr key={i} style={{ background: i % 2 === 0 ? "rgba(30,41,59,.35)" : "transparent" }}>
                    <Td left>{i + 1}</Td><Td left bold>{r.flag} {r.country}</Td><Td left>{r.index}</Td><NumCell val={r.ytd} />
                  </tr>
                ))}</tbody>
              </Tbl>
            </Section>
            <Section title="Bottom 5 Global Markets \u2014 YTD" icon="&#x1F30F;" accent="#f87171">
              <Tbl><thead><tr><Th left>#</Th><Th left>Market</Th><Th left>Index</Th><Th>YTD</Th></tr></thead>
                <tbody>{(data.bottomMarkets || []).map((r, i) => (
                  <tr key={i} style={{ background: i % 2 === 0 ? "rgba(30,41,59,.35)" : "transparent" }}>
                    <Td left>{i + 1}</Td><Td left bold>{r.flag} {r.country}</Td><Td left>{r.index}</Td><NumCell val={r.ytd} />
                  </tr>
                ))}</tbody>
              </Tbl>
            </Section>
          </div>
          <Section title="Global Market Snapshot" icon="&#x1F5FA;" accent="#06b6d4">
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 8 }}>
              {[...(data.topMarkets || []), ...(data.bottomMarkets || [])].map((m, i) => (
                <div key={i} style={{ background: "rgba(30,41,59,.4)", borderRadius: 8, padding: "10px 12px", textAlign: "center", border: `1px solid ${parseFloat(m.ytd) >= 0 ? "rgba(52,211,153,.15)" : "rgba(248,113,113,.15)"}` }}>
                  <div style={{ fontSize: 20 }}>{m.flag}</div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#e2e8f0", marginTop: 2 }}>{m.index}</div>
                  <div style={{ fontSize: 15, fontWeight: 800, fontFamily: "'Courier New',monospace", color: clr(m.ytd), marginTop: 2 }}>{fmt(m.ytd)}</div>
                </div>
              ))}
            </div>
          </Section>
        </div>
      )}

      {/* FOOTER */}
      <div style={{ textAlign: "center", padding: "14px 0 4px", borderTop: "1px solid rgba(100,116,139,.08)", marginTop: 10 }}>
        <div style={{ fontSize: 10, color: "#334155" }}>{data.source}. Auto-updates weekdays at 8:00 AM Dubai time. For informational purposes only.</div>
      </div>
    </div>
  );
}
