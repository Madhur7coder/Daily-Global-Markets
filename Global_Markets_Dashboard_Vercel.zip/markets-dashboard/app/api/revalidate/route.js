import { revalidatePath } from "next/cache";
import { NextResponse } from "next/server";

export async function GET(request) {
  // Optional: verify cron secret for security
  const authHeader = request.headers.get("authorization");
  if (
    process.env.CRON_SECRET &&
    authHeader !== `Bearer ${process.env.CRON_SECRET}`
  ) {
    // Allow Vercel cron (sends its own auth) or matching secret
    const isVercelCron = request.headers.get("x-vercel-cron");
    if (!isVercelCron) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  // Revalidate the homepage so it fetches fresh data
  revalidatePath("/");

  return NextResponse.json({
    ok: true,
    revalidated: true,
    timestamp: new Date().toISOString(),
    message: "Dashboard data will refresh on next visit",
  });
}
