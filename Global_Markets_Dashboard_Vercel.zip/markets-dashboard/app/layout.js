export const metadata = {
  title: "Global Markets Dashboard",
  description:
    "Daily briefing: indices, commodities, sectors, movers & global markets",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0 }}>{children}</body>
    </html>
  );
}
