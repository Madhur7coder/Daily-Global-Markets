import { fetchAllMarketData } from "../lib/fetchMarketData";
import Dashboard from "./components/Dashboard";

// Revalidate every 4 hours as a fallback; cron job triggers at 8AM Dubai
export const revalidate = 14400;

export default async function Page() {
  let data;
  try {
    data = await fetchAllMarketData();
  } catch (e) {
    console.error("Failed to fetch market data:", e);
    data = null;
  }

  return <Dashboard data={data} />;
}
